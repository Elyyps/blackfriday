module.exports = ["js", "jsx", "ts", "tsx", "mjs"];
