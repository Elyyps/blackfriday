const config = require("./server.base");

module.exports = {
  ...config,
  mode: "production"
};
