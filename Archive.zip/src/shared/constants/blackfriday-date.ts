export const BLACK_FRIDAY_DAY = 29;
export const BLACK_FRIDAY_MONTH = 11;
