export const CONFIG = {
  BASE_URL: "BASE_URL"
};
