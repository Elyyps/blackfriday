export enum KeyboardKeys {
  ESCAPE = "Escape",
  ARROW_LEFT = "ArrowLeft",
  ARROW_RIGHT = "ArrowRight"
}
