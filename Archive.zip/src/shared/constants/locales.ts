export const LOCALES = {
  EN: "en",
  NL: "nl",
  FR: "fr"
};
