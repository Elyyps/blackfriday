export const LOCALES = {
  SET_LOCALE: "SET_LOCALE"
};
