export const NEWS = {
  SET_CARDS: "SET_CARDS"
};
