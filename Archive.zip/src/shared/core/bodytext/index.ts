export * from "./bodytext.component";
