export * from "./deal-card.component";
