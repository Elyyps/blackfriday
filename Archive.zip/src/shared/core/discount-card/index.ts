export * from "./discount-card.component";
