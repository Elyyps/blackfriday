import * as React from "react";

export interface IEmptyPageComponentProps {}

const EmptyPageComponent: React.FunctionComponent = props => <div />;

export { EmptyPageComponent };
