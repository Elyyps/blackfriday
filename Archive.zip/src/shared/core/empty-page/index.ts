export * from "./empty-page.component";
