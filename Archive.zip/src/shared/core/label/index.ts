export * from "./label.component";
