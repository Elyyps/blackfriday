export * from "./link.component";
