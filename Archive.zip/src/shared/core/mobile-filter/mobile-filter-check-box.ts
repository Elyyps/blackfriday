export interface IMobileFilterCheckBox {
  checked: boolean;
  title: string;
}
