export * from "./resource-text.component";
