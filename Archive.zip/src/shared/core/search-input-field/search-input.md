This component requires a value controlled by a variable (state) on the parent.
