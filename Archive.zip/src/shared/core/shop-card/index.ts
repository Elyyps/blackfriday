export * from "./shop-card.component";
