export * from "./stars-rating.component";
