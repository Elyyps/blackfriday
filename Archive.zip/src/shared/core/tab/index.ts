export * from "./tab.component";
