// import * as React from "react";

// import { storiesOf } from "@storybook/react";
// import { withA11y } from "@storybook/addon-a11y";
// import { withProvider } from "@app/util";
// import { TabComponent, ITabsInterface } from "./tab.component";
// import { StoresOverviewContainer } from "@app/modules/stores-overview/container/stores-overview.container";
// const data: ITabsInterface[] = [
//   { title: "Winkels", content: <StoresOverviewContainer />, index: 1 },
//   { title: "Productdeals", content: <h1>Will be implemented</h1>, index: 2 }
// ];
// storiesOf("tabComponent", module)
//   .addDecorator(withA11y)
//   .addDecorator(withProvider)
//   .add("Basic implementation", () => <TabComponent tabs={data} />);
