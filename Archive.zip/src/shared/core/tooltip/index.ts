export * from "./tooltip.component";
