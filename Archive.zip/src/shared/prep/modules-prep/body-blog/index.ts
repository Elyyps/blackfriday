export * from "./body-blog.component";
