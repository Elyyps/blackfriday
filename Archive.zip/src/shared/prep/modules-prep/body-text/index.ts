export * from "./body-text.component";
