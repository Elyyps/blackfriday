export * from "./card-product.component";
