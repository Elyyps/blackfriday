export * from "./card-simple.component";
