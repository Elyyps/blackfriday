export * from "./image.component";
