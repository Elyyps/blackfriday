export * from "./tab.component";
export * from "./tab-container.component";
