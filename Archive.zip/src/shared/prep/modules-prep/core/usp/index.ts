export * from "./usp.component";
