export * from "./cta-small.component";
