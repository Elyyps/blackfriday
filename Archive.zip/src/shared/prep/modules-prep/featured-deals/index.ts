export * from "./featured-deals.component";
