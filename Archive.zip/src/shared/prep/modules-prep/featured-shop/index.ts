export * from "./featured-shop.component";
