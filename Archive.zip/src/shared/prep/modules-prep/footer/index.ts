export * from "./footer.component";
