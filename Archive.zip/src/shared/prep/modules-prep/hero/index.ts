export * from "./hero.component";
