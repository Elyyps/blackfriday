export * from "./posts-list.component";
