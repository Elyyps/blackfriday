declare module "enzyme-react-intl" {
  export function shallowWithIntl(component: any): any;
}
