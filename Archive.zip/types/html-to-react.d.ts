export namespace IsValidNodeDefinitions {
  function alwaysValid(): any;
}
export function Parser(): any;
export function ProcessNodeDefinitions(): any;
export function ProcessingInstructions(): any;
