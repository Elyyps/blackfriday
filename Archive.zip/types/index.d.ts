interface ExtendedWindow extends Window {
  __REDUX_DEVTOOLS_EXTENSION__: Function;
}
