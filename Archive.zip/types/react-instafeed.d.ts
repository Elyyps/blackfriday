export const buildUrl: any;
export default function _default(...args: any[]): any;
