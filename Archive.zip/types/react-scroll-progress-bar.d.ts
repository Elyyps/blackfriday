declare module "react-scroll-progress-bar" {}
